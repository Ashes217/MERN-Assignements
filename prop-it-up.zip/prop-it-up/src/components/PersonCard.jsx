

const PersonCard = ({firstName, lastName, hairColor,age}) => {

    // const {firstName, lastName, hairColor} = props;

    return (
        <div className='personCard'>
            <h2>{firstName} {lastName} </h2>
            <p>Age: {age} </p>
            <p>Hair Color: {hairColor} </p>
        </div>
    );
}

export default PersonCard
