import logo from './logo.svg';
import './App.css';
import PersonCard from './components/PersonCard';

function App() {
  return (
    <div className="App">
      <PersonCard firstName={'Sarah'} lastName={'Fortune'} age={24} hairColor={'red'} />

      <PersonCard firstName={'Diana'} lastName={'Moon'} age={27} hairColor={'Silver'} />

      <PersonCard firstName={'Leona'} lastName={'Sun'} age={24} hairColor={'red'} />

      <PersonCard firstName={'Caitlyn'} lastName={'Tales'} age={24} hairColor={'red'} />
    </div>
  );
}

export default App;
