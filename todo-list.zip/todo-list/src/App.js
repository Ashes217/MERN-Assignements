import logo from './logo.svg';
import './App.css';
import Form from './Components/Form';
import { List } from './Components/List';
import { useState } from 'react';

function App() {

  const [list, setList] = useState([
    {todo: 'Do my homework ;-;', complete: false},
    {todo: 'Clean my house', complete: false}


  ], [])



  return (
    <div className="App">
      <Form list = {list} setList = {setList} />
      <List list = {list} setList = {setList} />
    </div>
  );
}

export default App;
