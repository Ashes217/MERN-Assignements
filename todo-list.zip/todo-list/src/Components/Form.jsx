import React from 'react'
import { useState } from 'react'

const Form = ({list, setList}) => {

    const [task,setTask] = useState('');

    const submitHandler = (e) => {
        
        e.preventDefault();

        const newTask = {
            todo: task,
            complete: false
        }
        
        setList ([...list, newTask])
        setTask('')
    }

    return (
        <div>
            <h1>To Do list</h1>

            <form onSubmit={submitHandler}>

                <input type="text" name="" id="" value={task} onChange={ (e) => setTask(e.target.value) } />
                
                <button>Add Task</button>
            </form>
        </div>
)
}

export default Form