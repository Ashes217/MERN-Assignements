import React from "react";

export const List = ({ list, setList }) => {
  //complete a todo it will cross it out
  const done = (item) => {
    item.complete = !item.complete;
    setList([...list]);
};

  // clicking the button will delete the todo
const deleteMe = (value) => {
    setList(list.filter((item) => item.todo !== value));
};

return (
    <div>
    <ul>
        {list.map((item, index) => (
        <li className="nold">
            <input type="checkbox" onChange={(e) => done(item)} />
            <p className={item.complete ? "complete" : null}>{item.todo}</p>
            <button onClick={(e) => deleteMe(item.todo)}>Delete</button>
        </li>
        ))}
    </ul>
    </div>
);
};
