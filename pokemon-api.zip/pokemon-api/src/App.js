import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';

function App() {
  
  
  
  const [pokemonList, setPokemonList] = useState([]);

  // When we make a request to a serve API or an API this is an Asynchronous request (AJAX)

  //Promise is an asynchronous operation. This returns somethings and with it we need to have a success option and a fail option
  
  // URL needed to access the API
  // https://pokeapi.co/api/v2/pokemon?limit=807
  
    useEffect(() => {
      //pass in an address we want to get data from
      fetch(' https://pokeapi.co/api/v2/pokemon?limit=807')
      .then((res) => {
        return res.json();
      })
      .then((result) => {
        console.log(result)
        setPokemonList(result.results)
      })
      .catch((err) => {
        console.log(err)
      })
    }, [])
  
  return (

    <div className="App">

      <button>Fetch Pokemon</button>
      
      <ul>

      {
        pokemonList.map((pokemon, index) => (
          
          <li  key={index}>  {pokemon.name}</li>
          
        ))
      }

      </ul>
      
    </div>
  );
}

export default App;
