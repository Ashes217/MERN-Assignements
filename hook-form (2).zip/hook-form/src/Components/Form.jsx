import React from 'react'
import { useState } from 'react'

export const Form = () => {

    const [firstName,setFirstName] = useState('');
    const [lastName,setLastName] = useState('');
    const [email,setEmail] = useState('');
    const [password,setPassword] = useState('');
    const [confirmPassword,setConfirmPassword] = useState('');

    const obj = {
        firstName,
        lastName,
        email,
        password,
        confirmPassword
    }

    const submitHandler = (e) => {
        
        e.preventDefault();

        console.log(obj);


    }

return (
    <div>
        <form  className="form col-4 mx-auto" onSubmit={submitHandler}>

            <label htmlFor="" className='form-label'>First Name:</label>
            <input type="text"  onChange={(e) => setFirstName(e.target.value)} className = "form-control"/>
            {firstName.length < 2 && firstName.length > 0 ? (<p> First Name must be at least 2 characters</p>) : null}

            <label htmlFor="" className='form-label'>Last Name: </label>
            <input type="text"  onChange={(e) => setLastName(e.target.value) } className = "form-control"/>
            {lastName.length < 2 && lastName.length > 0 ? (<p> Last Name must be at least 2 characters</p>) : null}

            <label htmlFor="" className='form-label'>Email: </label>
            <input type="email"  onChange={(e) => setEmail(e.target.value) } className = "form-control"/>
            {email.length < 5 ? <p>Email must be at least 5 characters</p> : null }

            <label htmlFor=" " className='form-label'>Password: </label>
            <input type="password"  onChange={(e) => setPassword(e.target.value)} className = "form-control"/>
            {password.length < 8 ? ( <p>Password must be at least 8 characters</p> ) : null }

            <label htmlFor="" className='form-label'>Confirm Password: </label>
            <input type="password"  onChange={(e) => setConfirmPassword(e.target.value) } className = "form-control"/>
            {confirmPassword !== password ? <p>Confirm Password must match Password</p> : null }

            <button >Confirm</button>
            </form>

            <p>First Name: {firstName} </p>
            <p>Last Name: {lastName} </p>
            <p>Email: {email} </p>
            <p>Password: {password} </p>
            <p>Confirmed Password: {confirmPassword} </p>
    </div>
)
}

export default Form