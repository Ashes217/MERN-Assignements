
import React, {useState} from 'react';
const PersonCard = ({firstName, lastName, hairColor,age}) => {

    // using useState to change the age 
    const [currentAge, setCurrentAge] = useState(age);
    // const {firstName, lastName, hairColor} = props;

    return (
        <div className='personCard'>
            <h2>{firstName} {lastName} </h2>
            <p>Age: {currentAge} </p>
            <p>Hair Color: {hairColor} </p>
            <button onClick={() => setCurrentAge(currentAge + 1)}> Birthday Button for  {firstName} {lastName} </button>

        </div>
    );
}

export default PersonCard
